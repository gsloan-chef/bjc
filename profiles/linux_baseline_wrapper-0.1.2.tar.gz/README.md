# Linux Baseline Wrapper Profile

Wraps the default linux-security-baseline profile, and excludes rules os-08 and os-10.
